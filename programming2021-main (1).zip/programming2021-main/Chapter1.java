
public class Chapter1
{
	
	public static void main (String[] args)
	{
		int a = 17;
		int b = 23;
		int c = a * b;
		IBIO.output ("the product of " + a + " and " + b + " is " + c);

	}
}

