/*
 * Hello world 26 Aug 2021
 * IBS1 Comp Sci
 */

public class HelloWorld
{
	public static void main(String[] args)
	{
		System.out.print("Hello Grade 11 2021!!! ");
		System.out.println("IS THIS COOL OR WHAT?!");
		IBIO.out("Hello Grade 11 2021!!! ");
		IBIO.output("IS THIS COOL OR WHAT?!");
		IBIO.output("BYE");
	}
}
