
public class Example2
{
	
	public static void main (String[] args)
	{
		int a = 16;
		int b = 17;
		int c = a * b;
		IBIO.output("The product of " + a + " and " + b + " is " + c);
		
	}
}

