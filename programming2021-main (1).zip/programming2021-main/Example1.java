public class Example1
{
	public static void main(String args[])
	{
		int x = 16;
		String name = IBIO.input("Name? ");
		IBIO.output("the number was" + x);
		IBIO.output(x + " was the number");	
		IBIO.output(x + " was " + name + "'s age");
	}
}


